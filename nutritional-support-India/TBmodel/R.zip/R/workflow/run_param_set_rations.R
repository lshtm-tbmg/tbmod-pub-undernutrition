run_param_set_rations <- function(model, cc, params, params_uid, vx_chars, rr_pct) {
  
  combined_ipj <- list()
  
  # set.paths = initialize the params
  model_paths <- model$set.paths(countrycode  = cc,
                                 xml          = vx_chars$xml,
                                 parameters   = vx_chars$input)
  
  if (grepl("baseline", vx_chars$runtype)){
    scen_baseline = NULL
  } else {
    scen_baseline = model$baseline_output 
  } 
  
  # Run the model with the parameter set
  output = model$run(model_paths, new.parameter.values = params, baseline = scen_baseline, output.flows = F)
  
  #### n_epi
  if (T){
    counts <- output$stocks
    counts <- counts[age_from == 0 & age_thru == 99, ][,AgeGrp := "[0,99]"]
    counts <- counts[, !c("age_from", "age_thru")]
    
    #### Incidence
    inc <- counts[TB == "Dscount",]
    inc <- inc[, .(N_inc = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    inc <- inc[, Year := floor(Year)]
    
    #### Mortality
    mort <- counts[TB == "TBdead",]
    mort <- mort[, .(N_mort = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    mort <- mort[, Year := floor(Year)]
    
    #### Mortality - on treatment
    mort_tx <- counts[TB == "TTBdeadcount",]
    mort_tx <- mort_tx[, .(N_mort_tx = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    mort_tx <- mort_tx[, Year := floor(Year)]
    
    # All BMI 
    bmi <- counts[TB == "Un" | TB == "L0" | TB == "Ls" | TB == "Lf" | TB == "Dc" | 
                    TB == "Ds" | TB == "OTchild" |TB == "OTadult" | TB == "T" | TB == "R"]
    bmi <- bmi[, .(N_bmi = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    bmi <- bmi[, Year := floor(Year)]
    
    # TB BMI
    bmi_prev <- counts[TB == "Dc" | TB == "Ds"]
    bmi_prev <- bmi_prev[, .(N_bmi_prev = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    bmi_prev <- bmi_prev[, Year := floor(Year)]
    
    # OTadult
    notif <- counts[TB == "OTadultcount",]
    notif <- notif[, .(N_notif = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    notif <- notif[, Year := floor(Year)]
    
    # Combine everything into one dataset
    n_epi <- bmi[inc, on = .(Country = Country, Year = Year, AgeGrp = AgeGrp, VXa = VXa, BMI = BMI)]
    n_epi <- n_epi[bmi_prev, on = .(Country = Country, Year = Year, AgeGrp = AgeGrp, VXa = VXa, BMI = BMI)]
    n_epi <- n_epi[mort, on = .(Country = Country, Year = Year, AgeGrp = AgeGrp, VXa = VXa, BMI = BMI)]
    n_epi <- n_epi[mort_tx, on = .(Country = Country, Year = Year, AgeGrp = AgeGrp, VXa = VXa, BMI = BMI)]
    n_epi <- n_epi[notif, on = .(Country = Country, Year = Year, AgeGrp = AgeGrp, VXa = VXa, BMI = BMI)]
    
    rm(counts)
    rm(bmi)
    rm(bmi_prev)
    rm(inc)
    rm(mort)
    rm(notif)
    
    # Add the vaccine characteristics
    combined_ipj[["n_epi"]] <- n_epi[, `:=`(uid     = params_uid,
                                            runtype = vx_chars$runtype)]
  }
  
  #### cc_TB
  if (T){
    counts <- setDT(output$stocks)
    counts <- counts[grep("count$", counts$TB),]
    counts <- counts[!(year %% 0.5 == 0),]
    counts <- counts[!(age_from == 0 & age_thru == 99),]
    counts$AgeGrp = ""
    counts <- counts[age_from == 80  & age_thru == 89, AgeGrp := "(80,89]"]
    counts <- counts[age_from == 90  & age_thru == 99, AgeGrp := "(90,99]"]
    sel = counts$age_from<80
    counts[sel,]$AgeGrp = as.character(paste0("(", counts[sel,]$age_from, ",", counts[sel,]$age_from, "]"))
    
    counts <- counts[, !c("age_from", "age_thru")]
    counts <- counts[, year := floor(year)]
    
    inc <- counts[TB == "Dscount" ,]
    inc <- inc[, .(Total_Inc = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    inc <- inc[, Total_Inc_DS := (1-rr_pct)*Total_Inc][, Total_Inc_RR := (rr_pct)*Total_Inc]
    inc <- inc[, Year := floor(Year)]
    
    notif <- counts[TB == "OTadultcount" | TB == "OTchildcount", ]
    notif <- setDT(notif)
    notif <- notif[, .(Total_Notif = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    notif <- notif[, Total_Notif_DS := (1-rr_pct)*Total_Notif][, Total_Notif_RR := (rr_pct)*Total_Notif]
    notif <- notif[, Year := floor(Year)]
    
    ####### INDu Treatment Success
    trt_succ <- counts[(TB == "OTDccount" | TB == "OTRcount" | TB == "TTBdeadcount"),]
    
    # 1. TREATMENT COMPLETION: nodeadR = flows into R from T
    nodeadR  <- trt_succ[TB == "OTRcount", .(Total_complete = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    
    # 2. TREATMENT NON-COMPLETION: nodeadDc = flows into Dc from T
    nodeadDc <- trt_succ[TB == "OTDccount", .(Total_nocomplete = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    
    # 3. ON-TREATMENT MORTALITY: deadT = flows into TBdead from T 
    deadT <- trt_succ[TB == "TTBdeadcount", .(Total_dead = sum(value)), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    
    trt_succ <- merge(nodeadR, nodeadDc)
    trt_succ <- merge(trt_succ, deadT)
    
    # Calc the proportion completions of all outcomes (complete / (complete + no complete + dead))
    trt_succ <- trt_succ[, Total_compl_frac := Total_complete / (Total_complete + Total_nocomplete + Total_dead)]
    
    # Calc the proportion completions of all outcomes (complete / (complete + no complete + dead)) for DS and RR tb separately
    trt_succ <- trt_succ[, Total_compl_frac_DS := (1-rr_pct)*Total_compl_frac][,Total_compl_frac_RR := (rr_pct)*Total_compl_frac]
    
    trt_succ <- trt_succ[, .(Country, Year, AgeGrp, VXa, BMI, Total_compl_frac_DS, Total_compl_frac_RR, Total_compl_frac)]
    
    inc   <- inc[Year < 2041,]
    notif <- notif[Year < 2041,]
    trt_succ <- trt_succ[Year < 2041,]
    
    TB_inc_notif <- inc[notif, on = .(Country = Country, Year = Year, AgeGrp = AgeGrp, VXa = VXa, BMI = BMI)]
    TB_inc_notif <- TB_inc_notif[trt_succ, on = .(Country = Country, Year = Year, AgeGrp = AgeGrp, VXa = VXa, BMI = BMI)]
    
    combined_ipj[["cc_TB"]] <- TB_inc_notif[, `:=`(UID = params_uid,
                                                   Runtype = vx_chars$runtype,
                                                   Scenario = vx_chars$runtype)]
    rm(inc)
    rm(notif)
    rm(deadT)
    rm(nodeadDc)
    rm(nodeadR)
    rm(trt_succ)
    rm(TB_inc_notif)
    rm(counts)
    gc(full= TRUE)
    
    # Number vaccinated per year (here, number of people in rations count boxes)
    # Note: vaccinated != vaccine protected
    tb_vxa <- setDT(output$stocks)
    tb_vxa <- tb_vxa[grep("count$", tb_vxa$VXa),]
    tb_vxa <- tb_vxa[!(grep("count$", tb_vxa$TB)),]
    tb_vxa <- tb_vxa[!(year %% 0.5 == 0),]
    tb_vxa <- tb_vxa[!(age_from == 0 & age_thru == 99),]
    tb_vxa$AgeGrp = ""
    tb_vxa <- tb_vxa[age_from == 80  & age_thru == 89, AgeGrp := "(80,89]"]
    tb_vxa <- tb_vxa[age_from == 90  & age_thru == 99, AgeGrp := "(90,99]"]
    sel = tb_vxa$age_from<80
    tb_vxa[sel,]$AgeGrp = as.character(paste0("(", tb_vxa[sel,]$age_from, ",", tb_vxa[sel,]$age_from, "]"))
    tb_vxa <- tb_vxa[, !c("age_from", "age_thru")]
    
    tb_vxa <- tb_vxa[,.(Number_rations = abs(sum(value))), by = .(Country = country, Year = year, AgeGrp, VXa, BMI = RISK)]
    tb_vxa <- tb_vxa[, Year := floor(Year)]
    tb_vxa <- tb_vxa[Year < 2041,]
    
    combined_ipj[["cc_VXa_count"]] <- tb_vxa[, `:=`(UID = params_uid,
                                                    Runtype = vx_chars$runtype,
                                                    Scenario = vx_chars$runtype)]
    rm(tb_vxa)
    
    ### Population Size by Single ages
    population <- setDT(output$population)
    population <- population[year >= 1998,]
    population <- population[year %% 1 == 0.5,] # use the average of the year for the stocks
    population <- melt(population, id.vars = c("year", "country"),
                       variable.name = "age", value.name = "Population")
    population$age = as.integer(as.character(population$age))
    population$AgeGrp = "-1"
    sel = population$age<80
    population[sel,]$AgeGrp = as.character(paste0("(", population[sel,]$age, ",", population[sel]$age, "]"))
    sel = population$age==80
    population[sel,]$AgeGrp = "(80,89]"
    sel = population$age==90
    population[sel,]$AgeGrp = "(90,99]"
    
    population = population[,-c("age")]
    
    # Subset the variables and make sure the capitals are correct
    population <- population[, .(Country = country, Year = year, AgeGrp, Population)]
    population <- population[, Year := floor(Year)]
    population <- population[Year < 2041,]
    
    combined_ipj[["cc_pop"]] <- population[, `:=`(UID = params_uid,
                                                  Runtype = vx_chars$runtype,
                                                  Scenario = vx_chars$runtype)]
    rm(population)
    
  }
  
  #### cc_TB_HIV: TB distribution by age
  if(T){
    
    stocks_ipj <- setDT(output$stocks)
    stocks_ipj <- stocks_ipj[!(grep("count$", stocks_ipj$VXa)),]
    stocks_ipj <- stocks_ipj[!(grep("count$", stocks_ipj$TB)),]
    stocks_ipj <- stocks_ipj[!(year %% 0.5) == 0,]
    stocks_ipj <- stocks_ipj[!(age_from == 0 & age_thru == 99),]
    
    stocks_ipj <- stocks_ipj[age_from == 0  & age_thru == 0, AgeGrp := "(0,0]"]
    stocks_ipj <- stocks_ipj[age_from == 80  & age_thru == 89, AgeGrp := "(80,89]"]
    stocks_ipj <- stocks_ipj[age_from == 90  & age_thru == 99, AgeGrp := "(90,99]"]
    
    for (k in 1:79){
      stocks_ipj[age_from == k  & age_thru == k, AgeGrp := as.character(paste0("(", k, ",", k, "]"))]
    }
    
    stocks_ipj <- stocks_ipj[, !c("age_from", "age_thru")]
    stocks_ipj <- stocks_ipj[TB != "TBdead" & TB!= "Rdead", .(Raw_Value = sum(value)),
                             by = .(Country = country, Year = year, AgeGrp, TB)]
    
    stocks_ipj <- stocks_ipj[, Year := floor(Year)]
    
    combined_ipj[["cc_TB_HIV"]] <- stocks_ipj[, `:=`(UID = params_uid,
                                                     Runtype = vx_chars$runtype,
                                                     Scenario = vx_chars$runtype)]
  }
  
  rm(stocks_ipj)
  gc(full= TRUE)
  
  ##### cc_deaths
  if (T){
    
    # Get the TBHIV deaths (Econ output only)
    tbhiv_deaths <- setDT(output$dHIVTBx)
    tbhiv_deaths <- tbhiv_deaths[!(year %% 0.5) == 0,]
    tbhiv_deaths <- tbhiv_deaths[year >= 1998, `:=`(UID = params_uid,
                                                    Runtype = vx_chars$runtype)]
    
    tbhiv_deaths <- melt(tbhiv_deaths, id.vars = c("year", "country", "UID", "Runtype"),
                         variable.name = "AgeGrp", value.name = "Deaths")
    
    setnames(tbhiv_deaths, "Deaths", "TBHIVdeaths")
    
    # Get the Background deaths (Econ output only)
    bg_deaths <- setDT(output$dBGx)
    bg_deaths <- bg_deaths[year >= 1998][!(year %% 0.5 == 0),][, `:=`(UID = params_uid,
                                                                      Runtype = vx_chars$runtype)]
    
    bg_deaths <- melt(bg_deaths, id.vars = c("year", "country","UID", "Runtype"),
                      variable.name = "AgeGrp", value.name = "Deaths")
    
    setnames(bg_deaths, "Deaths", "BGdeaths")
    
    cc_alldeaths <- merge(bg_deaths, tbhiv_deaths)
    cc_alldeaths <- cc_alldeaths[, ALLdeaths := BGdeaths + TBHIVdeaths]
    
    rm(bg_deaths)
    rm(tbhiv_deaths)
    
    cc_alldeaths$AgeGrp = as.character(cc_alldeaths$AgeGrp)
    sel = as.integer(cc_alldeaths$AgeGrp) < 80
    cc_alldeaths[sel,]$AgeGrp = as.character(paste0("(", cc_alldeaths[sel,]$AgeGrp, ",", cc_alldeaths[sel,]$AgeGrp, "]"))
    
    cc_alldeaths <- cc_alldeaths[AgeGrp == "80", AgeGrp := "(80,89]"]
    cc_alldeaths <- cc_alldeaths[AgeGrp == "90", AgeGrp := "(90,99]"]
    
    
    # Subset the variables and make sure the capitals are correct
    cc_alldeaths <- cc_alldeaths[, Scenario := vx_chars$runtype]
    cc_alldeaths <- cc_alldeaths[, year := floor(year)]
    cc_alldeaths <- cc_alldeaths[year < 2041]
    
    combined_ipj[["cc_deaths"]] <- cc_alldeaths[, .(Country = country, Year = year, UID,
                                                    Runtype, Scenario, AgeGrp, BGdeaths, TBHIVdeaths, ALLdeaths)]
    rm(cc_alldeaths)
    gc(full=TRUE)  
  }
  
  if (grepl("baseline", vx_chars$runtype)){
    model$baseline_output <- output
  }
  
  rm(output)
  combined_ipj
}

