#-----------------------------------------------
# Generate Epi Output for RATIONS modelling
# Rebecca Clark
# Updated 7 November 2024
#-----------------------------------------------

# 1. Set-up: 

# 1.1  Load in the required packages
suppressPackageStartupMessages({
  rm(list=ls())
  model = new.env()
  library(here)
  library(data.table)
  library(renv)
  library(digest)
  library(log4r)
  library(fst)
  library(arrow)
  library(logger)
  
  source(here("R", "include-v11.R"), model)
  source(here("R", "TBVx-run-v1.R"), model)
  source(here("R", "workflow", "run_param_set_rations.R"))
})


# 1.2  Set the country code, parameters, scenario characteristics 
cc <- "INDu"

s_scenarios <- fread("./processing_files/INDu_RATIONS_s_scenarios.csv")

grid_task_int <- 1
#grid_task_int <- as.numeric(Sys.getenv("SLURM_ARRAY_TASK_ID"))
parameters    <- fread(paste0("./processing_files/param_sets/INDu_params.csv"))
parameters    <- parameters[(10*(grid_task_int-1) + 1):(10*grid_task_int), ]
print(paste0("number of parameter sets to run = ", nrow(parameters)))
rr_pct <- 0.028 ## IND specific

if (grid_task_int == 1){
  dir.create("./epi_output_rations_HHC/")
  dir.create("./epi_output_rations_HHC/n_epi/")
  dir.create("./epi_output_rations_HHC/cc_TB/")
  dir.create("./epi_output_rations_HHC/cc_TB_HIV/")
  dir.create("./epi_output_rations_HHC/cc_deaths/")
  dir.create("./epi_output_rations_HHC/cc_pop/")
  dir.create("./epi_output_rations_HHC/cc_VXa_count/")
}

# 3. Set-up and generate the output
for (j in 1:nrow(parameters)) {
  
  print(paste0("parameter set = ", j))
  
  params     <- parameters[j, ]
  params_uid <- params[, uid]
  params     <- params[, !c("uid", "nhits")]
  params     <- unlist(params)
  
  scenarios_j  <- s_scenarios[uid == params_uid,]$scenario
  
  vx_scenarios <- fread("./processing_files/INDu_RATIONS_HHC.csv")
  vx_scenarios <- vx_scenarios[, runtype := paste0(runtype, "_", scenarios_j)]
  vx_scenarios <- vx_scenarios[, xml := paste0(xml, "_", scenarios_j, ".xml")]
  
  print(vx_scenarios$runtype)
  
  cc_TB_param <- list()
  cc_pop_param <- list()
  cc_n_epi_param <- list()
  cc_TB_HIV_param <- list()
  cc_deaths_param <- list()
  cc_VXa_count_param <- list()
  
  for (i in 1:nrow(vx_scenarios)){
    
    vx_chars <- vx_scenarios[i,]
    
    print(paste0("Running scenario number ", i, ": ", vx_chars$runtype))
    
    # run the model with the row of parameters
    vx_scen_output <- run_param_set_rations(model, cc, params, params_uid, vx_chars, rr_pct)
    
    cc_TB_param[[i]] <- vx_scen_output[["cc_TB"]]
    cc_pop_param[[i]] <- vx_scen_output[["cc_pop"]]
    cc_n_epi_param[[i]] <- vx_scen_output[["n_epi"]]
    cc_TB_HIV_param[[i]] <- vx_scen_output[["cc_TB_HIV"]]
    cc_deaths_param[[i]] <- vx_scen_output[["cc_deaths"]]
    cc_VXa_count_param[[i]] <- vx_scen_output[["cc_VXa_count"]]
    
  }
  
  write_parquet(rbindlist(cc_n_epi_param), paste0("./epi_output_rations_HHC/n_epi/", params_uid, ".parquet"))
  write_parquet(rbindlist(cc_TB_param), paste0("./epi_output_rations_HHC/cc_TB/", params_uid, ".parquet"))
  write_parquet(rbindlist(cc_TB_HIV_param), paste0("./epi_output_rations_HHC/cc_TB_HIV/", params_uid, ".parquet"))
  write_parquet(rbindlist(cc_deaths_param), paste0("./epi_output_rations_HHC/cc_deaths/", params_uid, ".parquet"))
  write_parquet(rbindlist(cc_pop_param), paste0("./epi_output_rations_HHC/cc_pop/", params_uid, ".parquet"))
  write_parquet(rbindlist(cc_VXa_count_param), paste0("./epi_output_rations_HHC/cc_VXa_count/", params_uid, ".parquet"))
  
  rm(cc_n_epi_param)
  rm(cc_TB_param)
  rm(cc_TB_HIV_param)
  rm(cc_deaths_param)
  rm(cc_pop_param)
  rm(cc_VXa_count_param)
  
  print(paste0("End time for parameter set ", j, " = ", Sys.time()))
  
}


# ----end

