# --------------------------
# Generate the XMLs for the different scenarios
# Rebecca Clark
# Updated 7 November 2024
# --------------------------

rm(list=ls())
library(data.table)
library(xml2)

# --------- Baseline XMLs --------- 

baseline <- read_xml("./countries/INDu/parameters/template_XMLs/XMLinput_baseline.xml")
risk_inc <- xml_find_all(baseline, "//RISK/RISK.incidence")
file_list <- c("data/Undernutrition/BMI-mild-over_s", "data/Undernutrition/BMI-mild-moderate_s",
               "data/Undernutrition/BMI-mild-normal_s", "data/Undernutrition/BMI-over-mild_s",
               "data/Undernutrition/BMI-over-moderate_s", "data/Undernutrition/BMI-over-normal_s",
               "data/Undernutrition/BMI-moderate-mild_s", "data/Undernutrition/BMI-moderate-over_s",
               "data/Undernutrition/BMI-moderate-normal_s", "data/Undernutrition/BMI-normal-mild_s",
               "data/Undernutrition/BMI-normal-over_s", "data/Undernutrition/BMI-normal-moderate_s")

for (j in 1:30){
  
  for (i in 1:length(file_list)){
    child <- xml_child(risk_inc[[1]], i)
    xml_set_attr(child, 'incidence.data',
                 attr = "file", value = paste0(file_list[i], j, ".txt"))
  }
  write_xml(baseline, file = paste0("countries/INDu/parameters/baseline/XMLinput_baseline_s", j, ".xml"))
}



# ----------- RATIONS primary scenarios XMLs ----

scenarios <- fread("./processing_files/RATIONS_varying_XMLs_205080.csv")

folders <- unique(scenarios$scenario)
subfolders <- unique(scenarios$foldername)

for (i in 1:length(folders)){
  dir.create(paste0("./countries/INDu/parameters/rations/", folders[i]))
  
  for (j in 1:length(subfolders)){
    dir.create(paste0("./countries/INDu/parameters/rations/", folders[i], "/", subfolders[j]))
  }
}

for (i in 1:nrow(scenarios)){
  
  scenario      <- scenarios[i]$scenario
  coverage      <- scenarios[i]$coverage
  duration_w    <- scenarios[i]$duration_w
  duration_post <- scenarios[i]$duration_post
  foldername    <- scenarios[i]$foldername
  
  rations <- read_xml(paste0("./countries/INDu/parameters/template_XMLs/XMLinput_rations_", scenario, ".xml"))
  
  # Coverage
  if (scenario == "outcomes" | scenario == "BMI" | scenario == "TBPboth" | scenario == "all"){
    treat_vx_tbp <- xml_find_all(rations, xpath='//VXa/VXa.progression/treatment.matrix[@name = "TBPrations"]')
    xml_set_attr(x=xml_find_all(x = treat_vx_tbp, xpath='multiplier[@name = "TBPmult"]'),
                 attr="values", value = paste0("0, 2*", coverage/100))
  }
  
  if (scenario == "HHCbmi" | scenario == "HHCboth" | scenario == "all"){
    treat_vx_hhc <- xml_find_all(rations, xpath='//VXa/VXa.progression/treatment.matrix[@name = "HHCbmi"]')
    xml_set_attr(x=xml_find_all(x = treat_vx_hhc, xpath='multiplier[@name = "HHCmult"]'),
                 attr="values", value = paste0("0, 3.4*2*", coverage/100))
  }
  
  if (scenario == "HHC" | scenario == "HHCboth" | scenario == "all"){
    treat_Ds <- xml_find_all(rations, xpath='//TB/TB.progression/treatment.matrix[@name = "redincDs"]')
    treat_Ls <- xml_find_all(rations, xpath='//TB/TB.progression/treatment.matrix[@name = "redincLs"]')
    
    xml_set_attr(x=xml_find_all(x = treat_Ds, xpath='multiplier[@name = "redincDsmul"]'),
                 attr = "values", value = paste0("0, -3.4*(3419/100000)*(0.39)*2*", coverage/100))
    
    xml_set_attr(x=xml_find_all(x = treat_Ls, xpath='multiplier[@name = "redincLsmul"]'),
                 attr = "values", value = paste0("0, 3.4*(3419/100000)*(0.39)*2*", coverage/100))
  }
  
  
  # Duration
  if (scenario != "HHC"){
    params_vx <- xml_find_all(rations, xpath='//VXa/VXa.progression')
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "Un"][@name = "w"]'),
                 attr = "value", value = duration_w)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "L0"][@name = "w"]'),
                 attr = "value", value = duration_w)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "Lf"][@name = "w"]'),
                 attr = "value", value = duration_w)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "Ls"][@name = "w"]'),
                 attr = "value", value = duration_w)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "Ds"][@name = "w"]'),
                 attr = "value", value = duration_w)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "Dc"][@name = "w"]'),
                 attr = "value", value = duration_w)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "OTadult"][@name = "w"]'),
                 attr = "value", value = 0)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "OTchild"][@name = "w"]'),
                 attr = "value", value = 0)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "R"][@name = "w"]'),
                 attr = "value", value = duration_w)
  }
  
  if (scenario == "BMI" | scenario == "TBPboth" |scenario == "all"){
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "Un"][@name = "post"]'),
                 attr = "value", value = 0)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "L0"][@name = "post"]'),
                 attr = "value", value = 0)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "Lf"][@name = "post"]'),
                 attr = "value", value = 0)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "Ls"][@name = "post"]'),
                 attr = "value", value = 0)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "Ds"][@name = "post"]'),
                 attr = "value", value = duration_post)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "Dc"][@name = "post"]'),
                 attr = "value", value = duration_post)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "OTadult"][@name = "post"]'),
                 attr = "value", value = 0)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "OTchild"][@name = "post"]'),
                 attr = "value", value = 0)
    xml_set_attr(x=xml_find_all(x = params_vx, xpath='VXa.parameter[@TB.stage = "R"][@name = "post"]'),
                 attr = "value", value = duration_post)
  }
  
  
  # Underlying BMI distribution
  risk_inc <- xml_find_all(rations, "//RISK/RISK.incidence")
  
  if (scenario == "outcomes" | scenario == "HHC"){
    file_list <- c("data/Undernutrition/BMI-mild-over_s", "data/Undernutrition/BMI-mild-moderate_s",
                   "data/Undernutrition/BMI-mild-normal_s", "data/Undernutrition/BMI-over-mild_s",
                   "data/Undernutrition/BMI-over-moderate_s", "data/Undernutrition/BMI-over-normal_s",
                   "data/Undernutrition/BMI-moderate-mild_s", "data/Undernutrition/BMI-moderate-over_s",
                   "data/Undernutrition/BMI-moderate-normal_s", "data/Undernutrition/BMI-normal-mild_s",
                   "data/Undernutrition/BMI-normal-over_s", "data/Undernutrition/BMI-normal-moderate_s")
    
  } else {
    file_list <- c("data/RATIONS_none/BMI-mild-over_none_s", "data/RATIONS_none/BMI-mild-moderate_none_s",
                   "data/RATIONS_none/BMI-mild-normal_none_s", "data/RATIONS_none/BMI-over-mild_none_s",
                   "data/RATIONS_none/BMI-over-moderate_none_s", "data/RATIONS_none/BMI-over-normal_none_s",
                   "data/RATIONS_none/BMI-moderate-mild_none_s", "data/RATIONS_none/BMI-moderate-over_none_s",
                   "data/RATIONS_none/BMI-moderate-normal_none_s", "data/RATIONS_none/BMI-normal-mild_none_s",
                   "data/RATIONS_none/BMI-normal-over_none_s", "data/RATIONS_none/BMI-normal-moderate_none_s")
  }
  
  for (j in 1:30){
    
    for (k in 1:length(file_list)){
      child <- xml_child(risk_inc[[1]], k)
      xml_set_attr(child, 'incidence.data',
                   attr = "file", value = paste0(file_list[k], j, ".txt"))
    }
    write_xml(rations, paste0("countries/INDu/parameters/rations/", scenario, "/", foldername, "/XMLinput_rations_", scenario, "_s", j, ".xml"))
  }
  
}


# --------


# ----------- RATIONS varying incidence and mortality scenarios XMLs ----

scenarios <- c("inc", "mort", "both")

file_list <- c("data/RATIONS_none/BMI-mild-over_none_s", "data/RATIONS_none/BMI-mild-moderate_none_s",
               "data/RATIONS_none/BMI-mild-normal_none_s", "data/RATIONS_none/BMI-over-mild_none_s",
               "data/RATIONS_none/BMI-over-moderate_none_s", "data/RATIONS_none/BMI-over-normal_none_s",
               "data/RATIONS_none/BMI-moderate-mild_none_s", "data/RATIONS_none/BMI-moderate-over_none_s",
               "data/RATIONS_none/BMI-moderate-normal_none_s", "data/RATIONS_none/BMI-normal-mild_none_s",
               "data/RATIONS_none/BMI-normal-over_none_s", "data/RATIONS_none/BMI-normal-moderate_none_s")

for (k in 1:length(scenarios)){
  varying <- read_xml(paste0("./countries/INDu/parameters/template_XMLs/XMLinput_rations_all_vary", scenarios[k], ".xml"))
  
  risk_inc <- xml_find_all(varying, "//RISK/RISK.incidence")
  
  for (j in 1:30){
    
    for (i in 1:length(file_list)){
      child <- xml_child(risk_inc[[1]], i)
      xml_set_attr(child, 'incidence.data',
                   attr = "file", value = paste0(file_list[i], j, ".txt"))
    }
    write_xml(varying, file = paste0("countries/INDu/parameters/rations/vary/", scenarios[k], "/XMLinput_rations_vary", scenarios[k], "_s", j, ".xml"))
  }
  
}

# --------


# ------ end
